"""Package settings."""

fake = False
